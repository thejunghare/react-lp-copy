import { handleDelete, handleEdit } from "../helper";
import { Button } from "@/components/ui/button";
import TodoContext from "../context/Todo";
import { useContext } from "react";

function List() {
  const { setTodo, todos, setTodos, setCurrentId, setUpdateMode } =
    useContext(TodoContext);
  return (
    <>
      {todos.map((todo) => (
        <ul>
          <li key={todo.id}>{todo.title}</li>
          <Button
            onClick={() =>
              handleEdit(todo, setTodo, setCurrentId, setUpdateMode)
            }
          >
            update
          </Button>
          <Button onClick={() => handleDelete(todo.id, todos, setTodos)}>
            delete
          </Button>
        </ul>
      ))}
    </>
  );
}

export default List;
